import PlaygroundSupport
import SpriteKit
/*:
 ---
# Swift Roll
An artificial intelligence made in Swift to play a version of the old Nokia game "Rapid Roll", using Neural Networks and a Genetic Algorithm.
*/
/*:
 ---
 ## 🛑 Wait! Before you continue reading, **execute** this Playground Page.  ![alternate text](execute.png "Execute")
 ---
*/
/*:
 ## Introduction
 Ok, let's start to understand what's happening to the right ➡
 
 It's a simple game where you keep the ball alive by not touching the top spikes or falling to the bottom. To do this, the player hs to **keep jumping from paddle to paddle**.
 
 This playground is an artificial intelligence 🤖 that is able to learn how to do this 🎮.
 
 So let's start by just creating the scene for the game:
*/
let sceneView = SKView(frame: CGRect(x:0 , y:0, width: 300, height: 533))
let scene = GameScene()
scene.size = CGSize(width: 750, height: 1334)
// Set the scale mode to scale to fit the window
scene.scaleMode = .aspectFill
sceneView.ignoresSiblingOrder = true
//: And set it to the **Training** mode:
scene.gameMode = "train"

/*:
 ---
 ## Genetic Algorithm
 The learning method used is a **genetic algorithm**.
 
 This means that we create balls with random rules, called **genes**.
 
 The collection of a ball's genes is called a **genome** 🧬.
 
 By creating a whole bunch of genomes and making them play, we are able to select the best ones.
 
 Each round of all genomes 🧬 playing is called a **generation**.
 
 To the right ➡ you can see a generation being played, with all genomes running at the same time.
 
 At the end of a generation, we are able to select the best genomes 🧬 through a **fitness function**.
 
 In this case, the balls that achieve the highest score (at the top) are selected.
 */
//How many balls will be selected at the end of a generation
let breed_top = 20
/*:
 After this, we reproduce the genomes to form new ones.
 
 The hope is that by doing so, we are able to keep evolving new generations through a virtual **natural selection**.
 ### 🦠 ➡ 🐵
 */
// How many reproductions will occur for each top genome
let breed_count = 50
// Number of genomes for each reneration
let n_genomes = breed_top * breed_count
/*:
 ## Mutation
 To guarantee the evolution, 2 processes occur.
 
 The first one is **mutation**, where a gene is deformed by a random amount.
 
 ### ⚪ --MUTATION--> ⚫
 */
//The chance of a mutation happening in each gene
let mutate_chance = 80
//The range of how much a gene can be deformed
let mutationRange:CGFloat = 5

/*:
 ## Crossover
 And the second process that can occur is a crossover. It switches  genes between one genome and another:
 
 ### 🔴  +  ⚪   --CROSSOVER-->   ⚪
 ### 🔵  +  ⚫   ----------------->   🔵
 ### 🔴  +  🔵   --CROSSOVER-->   🔵
 ### ⚫  +  🔴   ----------------->   ⚫
 */
//The chance of a crossover happening in each gene
let crossover_chance = 80
/*:
 To play agains't the trained AI, go to the following playground page and see if you can beat it! [Versus Mode](@next)
 
 Take some time if you want to check out your own genetic algorithm evolving ➡
 
 A neat thing is that the ball's color is also a gene (🔴💚🔷), so you can see which genome is reproducing more (getting more constant throughout the learning, an then getting overtaken by a superior mutated genome.)
 */

//Scene Initiallization
scene.breed_top = breed_top
scene.breed_count = breed_count
scene.n_genomes = n_genomes
scene.crossover_chance = crossover_chance
scene.mutate_chance = mutate_chance
scene.mutationRange = mutationRange
sceneView.presentScene(scene)
PlaygroundSupport.PlaygroundPage.current.liveView = sceneView
