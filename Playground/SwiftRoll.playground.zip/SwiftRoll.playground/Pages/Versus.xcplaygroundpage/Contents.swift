import PlaygroundSupport
import SpriteKit
//Configure Scene
let scene = GameScene()
scene.gameMode = "versus"
scene.size = CGSize(width: 750, height: 1334)
scene.scaleMode = .aspectFill
/*:
 # Versus Mode
 Now that you know how the AI works, how about trying to beat one!
 
 Here you can see trained generations and play against them.
 */
/*:
 ---
 ## Controls:
 ### Move: ⬅ | ➡ or A | D
 ---
 */
/*:
 There are 680 generations to choose from, with generation 1 being the worst and generation 680 the best.
 */
//Choose the generation to go against
scene.v_generation = 650
/*:
 You play as the Red Ball 🔴, while the AI's color depends on the generation you are at.
 
 If the AI makes an error and dies before you, you can play until the end to see your best score. (The best generation can get up to 5000 points)
 */
/*:
 The configurations used for the AI seen here were:
*/
scene.breed_top = 40
scene.breed_count = 50
scene.crossover_chance = 80
scene.mutate_chance = 80
scene.mutationRange = 5
/*:
 Have Fun!
 [Training Mode](@previous)
 */
//Show Game
let sceneView = SKView(frame: CGRect(x:0 , y:0, width: 300, height: 533))
sceneView.ignoresSiblingOrder = true
sceneView.presentScene(scene)
PlaygroundSupport.PlaygroundPage.current.liveView = sceneView
